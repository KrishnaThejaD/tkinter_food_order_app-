import tkinter
from tkinter import *
from tkinter import ttk
from PIL import ImageTk,Image
from tkinter import messagebox
import pymysql
import re



ibaco = Toplevel()
ibaco.title("IBACO Home")
ibaco.geometry('1000x1000')

canvas = Canvas(ibaco, width =500, height=500)
canvas.place(x=0,y=0,relheight=1,relwidth=1)
img = ImageTk.PhotoImage(file="ice.jpg")
canvas.create_image(0,0, anchor=NW, image=img)




label = Label(ibaco,text='IBACO',font=("times new roman",18,"bold"),fg='black')
label.place(x=200,y=10)
    
l1 = Label(ibaco,text='Vanilla',font=("times new roman",15,"bold"),fg='black')
l1.place(x=60,y=70)
e1 = ttk.Combobox(ibaco,font=("arial",14),state='readonly',justify=CENTER)
e1['values']=("Select","1","2","3","4","5","6","7","8")
e1.place(x=400,y=70)
e1.current(0)
   
l2 = Label(ibaco,text='Dark chocolate',font=("times new roman",15,"bold"),fg='black')
l2.place(x=60,y=120)
e2 = ttk.Combobox(ibaco,font=("arial",14),state='readonly',justify=CENTER)
e2['values']=("Select","1","2","3","4","5","6","7","8")
e2.place(x=400,y=120)
e2.current(0)

l3 = Label(ibaco,text='Strawberry',font=("times new roman",15,"bold"),fg='black')
l3.place(x=60,y=170)
e3 = ttk.Combobox(ibaco,font=("arial",14),state='readonly',justify=CENTER)
e3['values']=("Select","1","2","3","4","5","6","7","8")
e3.place(x=400,y=170)
e3.current(0)
    
l4 = Label(ibaco,text='Redvelvet',font=("times new roman",15,"bold"),fg='black')
l4.place(x=60,y=220)
e4 = ttk.Combobox(ibaco,font=("arial",14),state='readonly',justify=CENTER)
e4['values']=("Select","1","2","3","4","5","6","7","8")
e4.place(x=400,y=220)
e4.current(0)
    
l5 = Label(ibaco,text='Butterscotch',font=("times new roman",15,"bold"),fg='black')
l5.place(x=60,y=270)
e5 = ttk.Combobox(ibaco,font=("arial",14),state='readonly',justify=CENTER)
e5['values']=("Select","1","2","3","4","5","6","7","8")
e5.place(x=400,y=270)
e5.current(0)

l6 = Label(ibaco,text='Black current',font=("times new roman",15,"bold"),fg='black')
l6.place(x=60,y=320)
e6 = ttk.Combobox(ibaco,font=("arial",14),state='readonly',justify=CENTER)
e6['values']=("Select","1","2","3","4","5","6","7","8")
e6.place(x=400,y=320)
e6.current(0)  

l7 = Label(ibaco,text='Mango',font=("times new roman",15,"bold"),fg='black')
l7.place(x=60,y=370)
e7 = ttk.Combobox(ibaco,font=("arial",14),state='readonly',justify=CENTER)
e7['values']=("Select","1","2","3","4","5","6","7","8")
e7.place(x=400,y=370)
e7.current(0)

l8 = Label(ibaco,text='Apple pie',font=("times new roman",15,"bold"),fg='black') 
l8.place(x=60,y=420)
e8 = ttk.Combobox(ibaco,font=("arial",14),state='readonly',justify=CENTER)
e8['values']=("Select","1","2","3","4","5","6","7","8")
e8.place(x=400,y=420)
e8.current(0)

def paymentcall():   
    import payment               

but1 = Button(ibaco,text='Order now',font=("times new roman",18),fg='black',bg='red',command=paymentcall,width=18)
but1.place(x=400,y=520)
    
 
    

ibaco.mainloop()
