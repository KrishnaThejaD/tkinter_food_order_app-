import tkinter
from tkinter import *
from tkinter import ttk
from PIL import ImageTk,Image
from tkinter import messagebox
import pymysql
import re

a2b = Toplevel()
a2b.title("A2B Restaurant")
a2b.geometry('1000x1000')
canvas = Canvas(a2b, width =500, height=500)
canvas.place(x=0,y=0,relheight=1,relwidth=1)
img = ImageTk.PhotoImage(file="idly.jpg")
canvas.create_image(0,0, anchor=NW, image=img)



l1 = Label(a2b,text='Idli',font=("times new roman",15,"bold"),cursor="hand2")
l1.place(x=60,y=70)
e1 = ttk.Combobox(a2b,font=("arial",14),state='readonly',justify=CENTER)
e1['values']=("Select","1","2","3","4","5","6","7","8")
e1.place(x=400,y=70)
e1.current(0)

l2 = Label(a2b,text='Dosa',font=("times new roman",15,"bold"))
l2.place(x=60,y=120)
e2 = ttk.Combobox(a2b,font=("arial",14),state='readonly',justify=CENTER)
e2['values']=("Select","1","2","3","4","5","6","7","8")
e2.place(x=400,y=120)
e2.current(0)

l3 = Label(a2b,text='Pongal',font=("times new roman",15,"bold"))
l3.place(x=60,y=170)
e3 = ttk.Combobox(a2b,font=("arial",14),state='readonly',justify=CENTER)
e3['values']=("Select","1","2","3","4","5","6","7","8")
e3.place(x=400,y=170)
e3.current(0)
    
l4 = Label(a2b,text='Puri',font=("times new roman",15,"bold"))
l4.place(x=60,y=220)
e4 = ttk.Combobox(a2b,font=("arial",14),state='readonly',justify=CENTER)
e4['values']=("Select","1","2","3","4","5","6","7","8")
e4.place(x=400,y=220)
e4.current(0)
    
l5 = Label(a2b,text='Chapati',font=("times new roman",15,"bold"),padx=5,pady=5)
l5.place(x=60,y=270)
e5 = ttk.Combobox(a2b,font=("arial",14),state='readonly',justify=CENTER)
e5['values']=("Select","1","2","3","4","5","6","7","8")
e5.place(x=400,y=270)
e5.current(0)

l6 = Label(a2b,text='Sweet box',font=("times new roman",15,"bold"),padx=5,pady=5)
l6.place(x=60,y=320)
e6 = ttk.Combobox(a2b,font=("arial",14),state='readonly',justify=CENTER)
e6['values']=("Select","1","2","3","4","5","6","7","8")
e6.place(x=400,y=320)
e6.current(0)  

l7 = Label(a2b,text='Coffee',font=("times new roman",15,"bold"),padx=5,pady=5)
l7.place(x=60,y=370)
e7 = ttk.Combobox(a2b,font=("arial",14),state='readonly',justify=CENTER)
e7['values']=("Select","1","2","3","4","5","6","7","8")
e7.place(x=400,y=370)
e7.current(0)

l8 = Label(a2b,text='Tea',font=("times new roman",15,"bold"),padx=5,pady=5) 
l8.place(x=60,y=420)
e8 = ttk.Combobox(a2b,font=("arial",14),state='readonly',justify=CENTER)
e8['values']=("Select","1","2","3","4","5","6","7","8")
e8.place(x=400,y=420)
e8.current(0)

def paymentcall():   
    import payment               

but1 = Button(a2b,text='Order now',font=("times new roman",18),fg='black',bg='red',command=paymentcall,width=18)
but1.place(x=400,y=520)
       

a2b.mainloop()
