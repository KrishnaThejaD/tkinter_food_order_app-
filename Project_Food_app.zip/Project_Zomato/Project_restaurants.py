import tkinter
from tkinter import *
from PIL import ImageTk, Image


win = Toplevel()


win.geometry('1400x1400')
canvas = Canvas(win, width =500, height=500)
canvas.place(x=0,y=0,relheight=1,relwidth=1)
img = ImageTk.PhotoImage(file="cook.jpg")
canvas.create_image(0,0, anchor=NW, image=img)

l1 = Label(win,text = " Restaurant at Home ",bd = 12,relief = GROOVE,fg = 'white',bg = 'black',
           font=("times new roman",30,"bold"),pady = 3, width=20)
l1.place(x=850,y=10)

def  kfc_f():
    import Project_kfc
    
b1 = Button(win,text='  KFC  ',cursor="hand2",activebackground='ivory2',bg='black',fg='white',
            command=kfc_f,width=17,borderwidth=3,font='bazooka  15  bold ',padx=5,pady=10,relief='raised')
b1.place(x=1000,y=120)

def it_food():
   import Project_a2b

b2 = Button(win,text='  A2B  ',activebackground='ivory2',cursor="hand2",command=it_food,bg='black',fg='white',
            width=17,borderwidth=3,font='bazooka  15  bold ',padx=5,pady=10,relief='raised')
b2.place(x=1000,y=210)

def ch_food():
    import Project_ibaco

b3 = Button(win,text=' IBACO ',activebackground='ivory2',cursor="hand2",command=ch_food,bg='black',fg='white',
            width=17,borderwidth=3,font='bazooka  15  bold ',padx=5,pady=10,relief='raised')
b3.place(x=1000,y=300)

def mexic_food():
    import Project_wangs   

b4 = Button(win,text=' WANGS ',command=mexic_food,activebackground='ivory2',cursor="hand2",bg='black',fg='white',
            width=17,borderwidth=3,font='bazooka  15  bold ',padx=5,pady=10,relief='raised')
b4.place(x=1000,y=390)

def mexic_food():
    import Project_dominos   

b4 = Button(win,text='Dominos',command=mexic_food,activebackground='ivory2',cursor="hand2",bg='black',fg='white',
            width=17,borderwidth=3,font='bazooka  15  bold ',padx=5,pady=10,relief='raised')
b4.place(x=1000,y=480)

win.mainloop()
